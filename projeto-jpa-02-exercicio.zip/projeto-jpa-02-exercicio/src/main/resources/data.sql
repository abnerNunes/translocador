insert into Salgadinho
(nome, nivel_sal, preco, apimentado)
values
('Queijo', 4, 5.5, true),
('Cheetos', 8, 2.5, false),
('Lettittos', 2, 1.5, true),
('Skilo', 4, 5.5, false),
('Pepputos', 1, 0.5, false);
