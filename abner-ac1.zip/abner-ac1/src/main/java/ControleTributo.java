import java.util.ArrayList;
import java.util.List;

public class ControleTributo {
    private List<Tributavel> listaTributavel;

    public ControleTributo(){ listaTributavel = new ArrayList<>();}

    public void adicionaTributavel(Tributavel t) {
        listaTributavel.add(t);
    }

    public void exibirLista() {
        System.out.println("\nLista dos itens tributáveis:");
        for (Tributavel t : listaTributavel) {
            System.out.println(t);
        }
    }

    public Double getTotalTributo(){
        Double total = 0.0;
        for (Tributavel t : listaTributavel) {
            total += t.getImposto();
        }
        return total;
    }
}
