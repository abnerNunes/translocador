public interface Tributavel {
    public Double getImposto();
}
