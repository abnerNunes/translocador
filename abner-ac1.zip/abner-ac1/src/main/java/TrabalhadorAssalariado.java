public class TrabalhadorAssalariado extends Trabalhador {

    private Double valorHoraExtra;
    private Integer qtdHoraExtra;

    public TrabalhadorAssalariado(String cpf, String nome, Double salario, Double valorHoraExtra, Integer qtdHoraExtra) {
        super(cpf, nome, salario);
        this.valorHoraExtra = valorHoraExtra;
        this.qtdHoraExtra = qtdHoraExtra;
    }

    public Double getValorHoraExtra() {
        return valorHoraExtra;
    }

    public void setValorHoraExtra(Double valorHoraExtra) {
        this.valorHoraExtra = valorHoraExtra;
    }

    public Integer getQtdHoraExtra() {
        return qtdHoraExtra;
    }

    public void setQtdHoraExtra(Integer qtdHoraExtra) {
        this.qtdHoraExtra = qtdHoraExtra;
    }

    @Override
    public String getCpf() {
        return super.getCpf();
    }

    @Override
    public void setCpf(String cpf) {
        super.setCpf(cpf);
    }

    @Override
    public String getNome() {
        return super.getNome();
    }

    @Override
    public void setNome(String nome) {
        super.setNome(nome);
    }

    @Override
    public Double getSalario() {
        return super.getSalario();
    }

    @Override
    public void setSalario(Double salario) {
        super.setSalario(salario);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public Double getRenda() {
        Double renda = getSalario() + (getValorHoraExtra()*getQtdHoraExtra());
        return renda;
    }

    @Override
    public Double getImposto() {
        Double imposto = getRenda() * 0.12;
        return imposto;
    }
}
