public class App {

    public static void main(String[] args) {
        TrabalhadorAssalariado trab = new TrabalhadorAssalariado("00000-111", "Roberta", 5000.0, 150.0, 5);
        TrabalhadorAssalariado trab2 = new TrabalhadorAssalariado("00000-222", "Randolinha", 1000.0, 20.0, 2);
        TrabalhadorEmpresario trab3 = new TrabalhadorEmpresario("00000-333", "Abner", 7000.0, 3000.0);
        Imovel casa = new Imovel(3000.0, 240.0, "Jardim SCS");
        Imovel casaPraia = new Imovel(5000.0, 45.0, "Jardim Imperador");

        System.out.println(trab);
        System.out.println(trab2);
        System.out.println(trab3);
        System.out.println(casa);
        System.out.println(casaPraia);

        ControleTributo controle = new ControleTributo();

        controle.adicionaTributavel(trab);
        controle.adicionaTributavel(trab2);
        controle.adicionaTributavel(trab3);
        controle.adicionaTributavel(casa);
        controle.adicionaTributavel(casaPraia);


        controle.exibirLista();

        System.out.printf("\nTotal de tributos: R$ %.2f\n",
                controle.getTotalTributo());
    }

    // A classe que eu adicionaria seria a classe carro,
    // que implementaria a interface Tributavel e teria seu
    // calculo feito com valorDoCarro * idadeDoCarro * 0.05;
}
