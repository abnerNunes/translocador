public class TrabalhadorEmpresario extends Trabalhador {
    private Double valorPartLucro;

    public TrabalhadorEmpresario(String cpf, String nome, Double salario, Double valorPartLucro) {
        super(cpf, nome, salario);
        this.valorPartLucro = valorPartLucro;
    }

    public Double getValorPartLucro() {
        return valorPartLucro;
    }

    public void setValorPartLucro(Double valorPartLucro) {
        this.valorPartLucro = valorPartLucro;
    }

    @Override
    public String getCpf() {
        return super.getCpf();
    }

    @Override
    public void setCpf(String cpf) {
        super.setCpf(cpf);
    }

    @Override
    public String getNome() {
        return super.getNome();
    }

    @Override
    public void setNome(String nome) {
        super.setNome(nome);
    }

    @Override
    public Double getSalario() {
        return super.getSalario();
    }

    @Override
    public void setSalario(Double salario) {
        super.setSalario(salario);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public Double getRenda() {
        Double renda = getSalario() + getValorPartLucro();
        return renda;
    }

    @Override
    public Double getImposto() {
        Double imposto = getRenda() * 0.25;
        return imposto;
    }
}
