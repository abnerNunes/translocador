public class Imovel implements  Tributavel{
    private Double valorM2;
    private Double area;
    private String bairro;

    public Imovel(Double valorM2, Double area, String bairro) {
        this.valorM2 = valorM2;
        this.area = area;
        this.bairro = bairro;
    }

    public Double getValorM2() {
        return valorM2;
    }

    public void setValorM2(Double valorM2) {
        this.valorM2 = valorM2;
    }

    public Double getArea() {
        return area;
    }

    public void setArea(Double area) {
        this.area = area;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    @Override
    public Double getImposto() {
        Double imposto = (getArea() * getValorM2()) * 0.05;
        return imposto;
    }

    @Override
    public String toString() {
        return "Imovel{" +
                "valorM2=" + valorM2 +
                ", area=" + area +
                ", bairro='" + bairro + '\'' +
                '}';
    }
}
