package sptech.projeto02;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/pokemons")
public class TreinadorPokemon {

    List<Pokemon> pokemonsLista = new ArrayList<>();
    @GetMapping("/cadastrar/{nome}/{tipo}/{forca}/{capturado}")
    public String cadastrarPokemon(
            @PathVariable String nome,
            @PathVariable String tipo,
            @PathVariable double forca,
            @PathVariable boolean capturado
    ){
        
    }
}
