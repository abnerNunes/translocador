package c102211000abnerbiscassinunes.c102211000abnerbiscassinunes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C102211000AbnerBiscassiNunesApplicationTests {

	@Test
	void contextLoads() {
	}

}
