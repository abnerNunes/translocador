package c102211000abnerbiscassinunes.c102211000abnerbiscassinunes.controle;

import org.springframework.web.bind.annotation.*;
import c102211000abnerbiscassinunes.c102211000abnerbiscassinunes.entidade.Usuario;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/usuarios")

public class Controller {

    private List<Usuario> users = new ArrayList<>();


    @GetMapping
    public String getUsers() {
        return users.toString();
    }

    @PostMapping
    public String postUser(@RequestBody Usuario novoUser){
        users.add(novoUser);
        return "Usuário" + novoUser.getNome() + " cadastrado no sistema.";
    }

        @PostMapping("/autenticacao/{usuario}/{senha}")
    public String getUser(@PathVariable String usuario, @PathVariable String senha){


        String msg = "";

        for (int i = 0; i < users.size(); i++){
            if (users.get(i).getUsuario().equals(usuario)){
                if (users.get(i).getSenha().equals(senha)){
                    users.get(i).setAutenticado(true);
                } else {
                    users.get(i).setAutenticado(false);
                }
            }else{
                users.get(i).setAutenticado(false);
            }
            if (users.get(i).getAutenticado().equals(true)){
                msg = "Usuário " + users.get(i).getNome() + "agora está autenticado";
            } else {
                msg = "Usuário" + usuario + " não encontrado";
            }
        }
        return msg;
    }

    @DeleteMapping("/autenticacao/{usuario}")
    public String logoff(@PathVariable String usuario){
        String msg = "";
        for (int i = 0; i < users.size(); i++) {
            if(users.get(i).getUsuario().equals(usuario)){
                if (users.get(i).getAutenticado().equals(true)){
                    msg = "Logoff do usuário" + users.get(i).getNome() + " concluído";
                } else {
                    msg = "Usuário" + usuario + " não está autenticado";
                }
            } else {
                msg = "Usuario" + usuario + "não encontrado";
            }
        }

        return msg;
    }

    // a intenção desse ENDPoint é excluir uma conta do "banco de dados"
    @DeleteMapping("/exclui/{usuario}/{senha}")
    public String removeUser(@PathVariable String usuario) {
        String msg = "";

        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).getUsuario().equals(usuario)) {
                msg = "Usuário excluído";
                users.remove(i);
            } else {
                msg = "Usuário não existe";
            }
        }
        return msg;
    }


}
