package c102211000abnerbiscassinunes.c102211000abnerbiscassinunes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C102211000AbnerBiscassiNunesApplication {

	public static void main(String[] args) {
		SpringApplication.run(C102211000AbnerBiscassiNunesApplication.class, args);
	}

}
