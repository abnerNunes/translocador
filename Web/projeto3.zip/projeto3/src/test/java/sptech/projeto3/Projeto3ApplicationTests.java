package sptech.projeto3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
