package sptech.projetojpa1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJpa1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoJpa1Application.class, args);
	}

}
