package sptech.projetojpa1.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import sptech.projetojpa1.entidade.Salgadinho;

public interface SalgadinhoRepository extends JpaRepository<Salgadinho, Integer> {

}
