package sptech.projetojpa1.controle;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sptech.projetojpa1.entidade.Salgadinho;
import sptech.projetojpa1.repositorio.SalgadinhoRepository;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/salgadinhos")
public class SalgadinhoController {

    @Autowired
    private SalgadinhoRepository repository;

    @PostMapping
    public ResponseEntity postSalgadinho(@RequestBody Salgadinho novoSalgadingho) {
        repository.save(novoSalgadingho);
        return ResponseEntity.status(201).build();
    }

    @GetMapping
    public ResponseEntity getSalgadinho() {
        List<Salgadinho> salgadinhos = repository.findAll();
        if (salgadinhos.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(salgadinhos);
    }


    @DeleteMapping("/{codigo}")
    public ResponseEntity deleteSalgadinho(
            @PathVariable int codigo) {
        if (repository.existsById(codigo)) {

            repository.deleteById(codigo);
            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(404).build();
    }

//    @GetMapping("/{codigo}")
//    public ResponseEntity pegaSal(@PathVariable int codigo) {
//        if (repository.existsById(codigo)) {
//            repository.findById(codigo);
//            return ResponseEntity.status(200).build();
//        }
//        return ResponseEntity.status(404).build();
//    }

//      @GetMapping("/{codigo}")
//        public ResponseEntity pegaSal(@PathVariable int codigo) {
//     Optional<Salgadinho> salgadinhoOptional = repository.findById(codigo);
//     if(salgadinhoOptional.isPresent()){
//     Salgadinho salgadinho = salgadinhoOptional.get();
//     return ResponseEntity.status(200).body(salgadinho);
//      }
//     return ResponseEntity.status(404).build();
//    }

    @GetMapping("/{codigo}")
    public ResponseEntity pegaSal(@PathVariable int codigo) {
        return ResponseEntity.of(repository.findById(codigo));
    }

    @PutMapping("/{codigo}")
    public ResponseEntity atualizaSheros(@PathVariable int codigo, @RequestBody Salgadinho salgadolas) {

        if (repository.existsById(codigo)) {
            salgadolas.setCodigo(codigo);
            repository.save(salgadolas);
            return ResponseEntity.status(200).build();
        }
        return  ResponseEntity.status(404).build();
    }


}
