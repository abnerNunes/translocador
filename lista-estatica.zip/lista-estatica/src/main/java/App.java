public class App {

    public static void main(String[] args) {
        ListaEstatica le = new ListaEstatica(5);

        le.adiciona(5);
        le.adiciona(10);
        le.adiciona(4);
        le.adiciona(4);
        le.exibe();
        System.out.println(le.contaCorrente(4));
        le.exibe();
        le.substitui(10, 2);
        le.exibe();
        le.adicionaNoInicio(1);
        le.exibe();
//        System.out.println(le.busca(1));
//        System.out.println(le.busca(10));
//        le.exibe();
    }
}
