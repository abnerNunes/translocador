public class ListaEstatica {

    private int[] vetor;
    private int nroElem;

    public ListaEstatica(int tamanhoMaximoLista){
        vetor = new int[tamanhoMaximoLista];
        nroElem = 0;
    }

    public void adiciona(int valor){
        if(nroElem >= vetor.length){
            System.out.println("O vetor está cheio");
        }else{
            vetor[nroElem++] = valor;
        }
    }

    public void exibe(){
        System.out.println("-".repeat(20));
        for (int i = 0; i < vetor.length; i++) {
            System.out.println(vetor[i]);
        }
        System.out.println("-".repeat(20));
    }

    public int busca(int elem){
        for (int i = 0; i < vetor.length; i++){
            if (vetor[i] == elem){
                return i;
            }
        }
        return -1;
    }

    public boolean removePeloIndice(int indice){
        if (indice < 0 || indice >= nroElem){
            return false;
        }
        for (int i = indice; i < nroElem -1; i++) {
            vetor[i] = vetor[i+1];
        }
        nroElem--;
        return true;
    }

    public boolean removeElemento(int elem){
        return removePeloIndice(busca(elem));
    }

    public boolean substitui(int valAnt, int valNovo){
        int indiceAnt = busca(valAnt);
        if(indiceAnt == -1){
            return false;
        }else{
            vetor[indiceAnt] = valNovo;
            return true;
        }
    }

    public int contaCorrente(int valor){
        int qtdVezesAparece = 0;
        for(int item : vetor){
            if (item == valor){
                qtdVezesAparece++;
            }
        }
        return qtdVezesAparece;
    }

    public void adicionaNoInicio(int valor){
        if (nroElem >= vetor.length){
            System.out.println("Lista cheia");
        }else{
            for (int i = nroElem; i >= 1; i--) {
                vetor[i] = vetor[i-1];
            }
            vetor[0] = valor;
            nroElem++;
        }
    }
}
