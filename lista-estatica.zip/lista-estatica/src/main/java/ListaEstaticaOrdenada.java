public class ListaEstaticaOrdenada extends ListaEstatica{

    public ListaEstaticaOrdenada(int tamanhoMaximoLista) {
        super(tamanhoMaximoLista);
    }

    @Override
    public void adiciona(int valor) {
        super.adiciona(valor);
    }
}
