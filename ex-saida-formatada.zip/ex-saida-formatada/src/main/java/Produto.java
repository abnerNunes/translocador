public class Produto {
    private int codProduto;
    private String nome;
    private double preco;
    private String avaliacao;
    private int qtdVendida;

    public Produto(int codProduto, String nome, double preco, String avaliacao) {
        this.codProduto = codProduto;
        this.nome = nome;
        this.preco = preco;
        this.avaliacao = avaliacao;
        this.qtdVendida = 0;
    }

    public void comprar(int qtdComprada){
        qtdVendida+=qtdComprada;
    }

    public double calcularFaturamento(){
        double faturamento = preco * qtdVendida;
        return faturamento;
    }



    public int getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(int codProduto) {
        this.codProduto = codProduto;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(String avaliacao) {
        this.avaliacao = avaliacao;
    }

    public int getQtdVendida() {
        return qtdVendida;
    }

    public void setQtdVendida(int qtdVendida) {
        this.qtdVendida = qtdVendida;
    }


}
