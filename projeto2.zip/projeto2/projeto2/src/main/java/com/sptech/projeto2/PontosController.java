package com.sptech.projeto2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PontosController {

    private int pontos;
    private int partidas;

    @GetMapping("/vitoria")
    public String ganhar(){
        pontos+=3;
        partidas++;
        return String.format("Ganhou!");
    }

    @GetMapping("/empate")
    public String empatar(){
        pontos+=1;
        partidas++;
        return String.format("Empatou.");
    }

    @GetMapping("/derrota")
    public String perder(){
       
        partidas++;
        return String.format("Perdeu :(");
    }

    @GetMapping("/pontuacao")
    public String pontuar(){
    String s = "";
        if (partidas<1) {
        s = "vc n jogou";

        }else {
            int maximo = partidas * 3;
            int aproveitamento =  (pontos * 100)/maximo;
            s = String.format("Você jogou %d e fez %d pontos, teve um aproveitamento de %d" , partidas, pontos, aproveitamento);
        }
        return s;
    }
}
