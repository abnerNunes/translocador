package sptech.projeto04.controle;

import org.springframework.web.bind.annotation.*;
import sptech.projeto04.entidade.Heroi;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/herois")

public class HeroiController {

    private List<Heroi> herois = new ArrayList<>();

    @GetMapping
    public List<Heroi> getHerois() {
        return herois;
    }

    @PostMapping
    public String postHeroi(@RequestBody Heroi novoHeroi){
        herois.add(novoHeroi);
        return "Admiro a Roberta";
    }

    @GetMapping("/{indice}")
    public Heroi getHeroi(@PathVariable int indice){
        Heroi msg = null;
        String a = "";
        if(indice>herois.size()){
            msg = null;
        } else {
            msg = herois.get(indice);
        }
        return msg;

    }

    @PutMapping("/{indice}")
    public String putHeroi(@PathVariable int indice, @RequestBody Heroi heroiAtt){
        String msg = "";
        if(indice>herois.size()){
            msg = "Nao existe";
        } else {
            herois.set(indice, heroiAtt);
            msg = "Robertaaaa";
        }
        return msg;
    }

    @DeleteMapping("/{indice}")
    public String removeHeroi(@PathVariable int indice){
        String msg = "";
        if(indice>herois.size()){
            msg = "Nao existe";
        } else {
        herois.remove(indice);
        msg = "Robertaaaaa";
    }
        return msg;
}}
