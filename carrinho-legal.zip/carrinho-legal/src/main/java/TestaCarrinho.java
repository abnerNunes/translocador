import java.util.ArrayList;
import java.util.Scanner;

public class TestaCarrinho {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Carrinho carrinho = new Carrinho(new ArrayList<>());

        int num = scan.nextInt();

        System.out.println("1.Adicionar Livro \n 2.Adicionar Dvd \n 3.Adicionar Serviço \n 4.Exibir Itens \n 5.Exibir total \n 6.Sair");
        switch(num){
            case 1:
                System.out.println("Insira as informações do Livro");
                in
        }
    }


}
