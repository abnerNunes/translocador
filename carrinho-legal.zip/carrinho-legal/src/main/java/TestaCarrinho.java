import java.util.ArrayList;
import java.util.Scanner;

public class TestaCarrinho {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Carrinho carrinho = new Carrinho(new ArrayList<>());

        int num = scan.nextInt();

        System.out.println("1.Adicio");
        switch(num){
            case 1:
                System.out.println("");
        }
    }


}
