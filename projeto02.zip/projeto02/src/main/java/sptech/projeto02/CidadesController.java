package sptech.projeto02;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/cidades")
public class CidadesController {


    @GetMapping("/listar")
    public String listar(){
        return "todas as cidades";
    }

    @GetMapping("/top-5")
    public String toper(){
        return "a, b e c";
    }

    @GetMapping
    public String home(){
        return "aa";
    }


}
