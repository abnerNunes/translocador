public abstract class Boneco {
    private String nome;
    private String marca;
    private int codigo;

    public Boneco(String nome, String marca, int codigo) {
        this.nome = nome;
        this.marca = marca;
        this.codigo = codigo;
    }

    public abstract void Interagir();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Boneco{" +
                "nome='" + nome + '\'' +
                ", marca='" + marca + '\'' +
                ", codigo=" + codigo +
                '}';
    }
}
