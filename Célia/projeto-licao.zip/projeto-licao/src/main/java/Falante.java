public class Falante extends Boneco{

    private int qtdFalas;

    public Falante(String nome, String marca, int codigo, int qtdFalas) {
        super(nome, marca, codigo);
        this.qtdFalas = qtdFalas;
    }

    @Override
    public void Interagir() {
        System.out.println("Olá Humanos!");
    }

    public int getQtdFalas() {
        return qtdFalas;
    }

    public void setQtdFalas(int qtdFalas) {
        this.qtdFalas = qtdFalas;
    }

    @Override
    public String toString() {
        return super.toString() + '\'' +
        ", qtdFalas:" + getQtdFalas();
    }
}
