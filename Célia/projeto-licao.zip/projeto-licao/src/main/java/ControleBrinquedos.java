import java.util.ArrayList;
import java.util.List;

public class ControleBrinquedos {
    private List<Boneco> boneco;


    public ControleBrinquedos(List<Boneco> boneco) {
        this.boneco = new ArrayList<>();
    }

    public void adicionaBoneco(Boneco b){
        boneco.add(b);
    }

    public void exibeItensLista(){
        for(Boneco b : boneco){
            System.out.println(b);
        }
    }


}
