public class Articulado extends Boneco{

    private int articulacoes;

    public Articulado(String nome, String marca, int codigo) {
        super(nome, marca, codigo);
        this.articulacoes = 0;
    }

    @Override
    public void Interagir() {
        articulacoes ++;
    }

    public int getArticulacoes() {
        return articulacoes;
    }

    public void setArticulacoes(int articulacoes) {
        this.articulacoes = articulacoes;
    }

    @Override
    public String toString() {
        return super.toString() + '\'' +
                ", articulacoes:" + getArticulacoes();
    }
}
