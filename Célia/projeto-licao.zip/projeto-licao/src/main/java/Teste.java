import java.util.ArrayList;

public class Teste {
    public static void main(String[] args) {

        Articulado bonecoArticulado = new Articulado("MaxSteel", "Hasbro", 1);
        Falante bonecoFalante = new Falante("Spoky", "Matel", 1, 4);

        ControleBrinquedos controle = new ControleBrinquedos(new ArrayList<>());

        controle.adicionaBoneco(bonecoArticulado);
        controle.adicionaBoneco(bonecoFalante);

        bonecoArticulado.Interagir();
        bonecoArticulado.Interagir();
        bonecoArticulado.Interagir();

        controle.exibeItensLista();

        System.out.println(bonecoArticulado.getArticulacoes());

        bonecoFalante.Interagir();
    }
}
