public class Teste {

    public static void main(String[] args) {
        int indRetornado;

        ListaOrdenada lista = new ListaOrdenada(5);


        lista.exibe();

        lista.adiciona(20);
        lista.adiciona(10);
        lista.adiciona(30);

        lista.exibe();

        lista.adiciona(40);
        lista.adiciona(50);
        System.out.println("\nAdicionando o sexto elemento");
        lista.adiciona(60);

        lista.exibe();

        System.out.println("\nBuscando o elemento 20");
        indRetornado = lista.busca(20);
        if (indRetornado == -1) {
            System.out.println("Numero 20 não foi encontrado");
        }
        else {
            System.out.println("Numero 20 encontrado na posição " + indRetornado);
        }

        System.out.println("\nBuscando o elemento 87");
        indRetornado = lista.busca(87);
        if (indRetornado == -1) {
            System.out.println("Elemento 87 não foi encontrado");
        }
        else {
            System.out.println("Elemento 100 encontrado no índice " + indRetornado);
        }

        System.out.println("\nRemover elemento índice 2");
        if (lista.removePeloIndice(2)) {
            System.out.println("Removeu elemento índice 2");
        }
        else {
            System.out.println("Remoção inválida");
        }

        lista.exibe();

        System.out.println("\nRemovendo elemento índice 0");
        if (lista.removePeloIndice(0)) {
            System.out.println("Removido elemento índice 0");
        }
        else {
            System.out.println("Remoção inválida");
        }

        lista.exibe();

        System.out.println("\nRemover elemento índice 4");
        if (lista.removePeloIndice(4)) {
            System.out.println("Removeu elemento índice 4");
        }
        else {
            System.out.println("Remoção inválida");
        }

        lista.exibe();

        System.out.println("\nRemover numero 30");
        if (lista.removeElemento(30)) {
            System.out.println("Removeu numero 30");
        }
        else {
            System.out.println("Remoção inválida");
        }

        lista.exibe();

        System.out.println("\nRemover numero 55");
        if (lista.removeElemento(55)) {
            System.out.println("Removeu numero 55");
        }
        else {
            System.out.println("Remoção inválida");
        }

        lista.exibe();

    }
}
