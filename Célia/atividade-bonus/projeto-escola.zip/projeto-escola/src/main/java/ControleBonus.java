import java.util.ArrayList;
import java.util.List;

public class ControleBonus {
    private List<Receptivel> func;

    public ControleBonus(List<Receptivel> func) {
        this.func = new ArrayList<>();
    }

    public void adicionaFunc(Receptivel r){
    func.add(r);
    }

    public void exibeItensLista(){
        for (Receptivel r : func){
            System.out.println(r);
        }
    }

    public double calculaTotalBonus(){
        Double soma = 0.0;
        for (Receptivel r : func){
            soma+=r.getValorBonus();
        }
        return soma;
    }
}
