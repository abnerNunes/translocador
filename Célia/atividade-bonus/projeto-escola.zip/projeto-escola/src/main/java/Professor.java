public class Professor extends Funcionario implements Receptivel {

    public Professor(String nome, Integer qtdHoras, Double valorHora) {
        super(nome, qtdHoras, valorHora);
    }

    @Override
    public String getNome() {
        return super.getNome();
    }

    @Override
    public void setNome(String nome) {
        super.setNome(nome);
    }

    @Override
    public Integer getQtdHoras() {
        return super.getQtdHoras();
    }

    @Override
    public void setQtdHoras(Integer qtdHoras) {
        super.setQtdHoras(qtdHoras);
    }

    @Override
    public Double getValorHora() {
        return super.getValorHora();
    }

    @Override
    public void setValorHora(Double valorHora) {
        super.setValorHora(valorHora);
    }

    @Override
    public String toString() {
        return super.toString();
    }

    @Override
    public Double getValorBonus() {
        Double bonus = getQtdHoras() * getValorHora() * 4.5 * 0.15;
        return bonus;
    }

}
