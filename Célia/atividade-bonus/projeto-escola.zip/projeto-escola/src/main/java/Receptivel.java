public interface Receptivel {
    public Double getValorBonus();
}
