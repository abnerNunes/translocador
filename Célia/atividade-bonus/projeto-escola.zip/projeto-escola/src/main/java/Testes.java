import java.util.ArrayList;

public class Testes {
    public static void main(String[] args) {
        Professor professor = new Professor("Roberta", 40, 100.0);
        Coordenador coordenador = new Coordenador("Abner", 40, 90.);

        ControleBonus cont = new ControleBonus(new ArrayList<>());

        Double bonusP = professor.getValorBonus();
        Double bonusC = coordenador.getValorBonus();

        cont.adicionaFunc(professor);
        cont.adicionaFunc(coordenador);

        cont.exibeItensLista();

        System.out.println(cont.calculaTotalBonus());
    }
}
