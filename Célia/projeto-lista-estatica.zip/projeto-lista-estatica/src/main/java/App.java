public class App {
    public static void main(String[] args) {
        ListaEstatica lista = new ListaEstatica(10);

        lista.adiciona(2);
        lista.adiciona(10);
        lista.adiciona(3);
        lista.adiciona(5);

        System.out.println("===========================");

        lista.exibe();

        System.out.println("===========================");

        System.out.println(lista.busca(5));

        System.out.println("===========================");

        System.out.println(lista.removeIndi(2));

        System.out.println("===========================");

        System.out.println(lista.removeElem(2));

        System.out.println("============================");

        lista.exibe();

        System.out.println("============================");
    }
}
