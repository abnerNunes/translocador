public class ListaEstatica {

    int[] vetor;
    int nroElem;

    public ListaEstatica(int tamanho) {
        this.vetor = new int[tamanho];
        this.nroElem = 0;
    }

    public void adiciona(int nro){

            if (nroElem == (vetor.length - 1)){
                System.out.println("Vetor cheio");
            }else{
                vetor[nroElem] = nro;
                nroElem++;
            }

    }

    public void exibe(){
        for (int i = 0; i < nroElem; i++){
            System.out.println(vetor[i]);
        }
    }

    public int busca(int elem){
        int retorno = -1;
        for (int i = 0; i < nroElem; i++){
            if (vetor[i] == elem){
                retorno = i;
            }
        }
        return retorno;
    }

    public boolean removeIndi(int indice){
        boolean retorno = false;
        if (indice > nroElem || indice <0){
            retorno = false;
        } else {
            for(int i = indice; i<=nroElem - 1;i++){
                vetor[i] = vetor[i+1];
                retorno = true;
                            }
            nroElem--;
        }
    return retorno;
    }

    public boolean removeElem(int elem){
        boolean retorno = false;
       for (int i = 0; i < nroElem - 1; i++){
           if(elem == vetor[i]){
              retorno = true;
               for(int j = i; j<=nroElem - 1;j++){
                   vetor[j] = vetor[j+1];
               }
               nroElem--;
           } 
       }
    return retorno;  
    }
    
}
