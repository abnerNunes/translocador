import java.util.ArrayList;

public class TestaAtributo {
    public static void main(String[] args) {
        Alimento ali = new Alimento(1, "Maça", 2.0, 5);
        Perfume perf = new Perfume(2, "Urbano", 80.0, "Maconha");
        Servico serv = new Servico("Spotify", 20.0);
        Tributo trib = new Tributo(new ArrayList<>());

        trib.adicionaTributavel(ali);
        trib.adicionaTributavel(perf);
        trib.adicionaTributavel(serv);

        trib.calcularTotalTributo();

        Double total = trib.calcularTotalTributo();
        System.out.println(total);
    }
}
