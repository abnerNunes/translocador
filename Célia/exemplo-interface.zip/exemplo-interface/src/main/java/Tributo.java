import java.util.ArrayList;

public class Tributo {

    private ArrayList<Tributavel> listaTrib;

    public Tributo(ArrayList<Tributavel> listaTrib) {
        this.listaTrib = new ArrayList<>();
    }

    public void adicionaTributavel(Tributavel t){
        listaTrib.add(t);
    }

    public Double calcularTotalTributo(){
        Double soma = 0.0;
        for (Tributavel t : listaTrib){
            soma += t.getValorTributo();
        }
        return  soma;
    }
}
