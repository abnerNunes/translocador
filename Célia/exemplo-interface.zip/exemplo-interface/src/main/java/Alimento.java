public class Alimento extends Produto{

    // Atributos

    private Integer qtdVitamina;

    //Construtor

    public Alimento(Integer codigo, String descricao, Double preco, Integer qtdVitamina) {
        super(codigo, descricao, preco);
        this.qtdVitamina = qtdVitamina;
    }


    //Metdos


    @Override
    public Double getValorTributo() {
        Double valorTributo = getPreco()*0.15;
        return valorTributo;
    }


    //String

    @Override
    public String toString() {
        return "Alimento{" +
                "qtdVitamina=" + qtdVitamina +
                "tributo=" + getValorTributo() +
                '}' + super.toString();
    }
}
