public class Perfume extends Produto{
    private String fragrancia;

    public Perfume(Integer codigo, String descricao, Double preco, String fragrancia) {
        super(codigo, descricao, preco);
        this.fragrancia = fragrancia;
    }

    @Override
    public Double getValorTributo() {
        Double valorTributo = getPreco()*0.27;
        return valorTributo;
    }

    @Override
    public String toString() {
        return "Perfume{" +
                "fragrancia='" + fragrancia + '\'' +
                "tributo=" + getValorTributo() +
                '}' + super.toString();
    }
}
