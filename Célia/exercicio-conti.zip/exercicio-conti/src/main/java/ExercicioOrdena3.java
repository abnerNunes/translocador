public class ExercicioOrdena3 {
    public static void main(String[] args) {
        Integer v[]= {1, 7, 5, 2, 7, 1, 9, 2};
        int i, j, aux;

        for (i = 0; i < v.length-1; i++){
            for (j = 1; j<v.length-i; j++){
                if (v[j-1]>v[j]){
                    aux = v[i];
                    v[i] = v[j-];
                    v[j] = aux;
                }
            }
        }
    }
}
