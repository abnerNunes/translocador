import java.util.Scanner;

public class ExercicioOrdena1 {
    public static void main(String[] args) {

        Integer v[]= {1, 7, 5, 2, 7, 1, 9, 2};
        Integer contaTroca = 0;
        Integer contaCompa = 0;


        for (int i = 0; i < v.length; i++){
            for (int j = i + 1; j<v.length; j++){
                contaCompa++;
                if (v[j]<v[i]){
                    contaTroca++;
                    int aux = v[i];
                    v[i] = v[j];
                    v[j] = aux;
                }
            }
        }

        for (int i = 0; i<v.length; i++){
            System.out.println(v[i]);
        }

        System.out.println("Comparações" + contaCompa + " Trocas: " + contaTroca);
    }
}
