import java.util.Scanner;

public class ExercicioCarro {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Scanner leitor2 = new Scanner(System.in);
        String[] vetor = new String[5];
        Integer[] vetor2 = new Integer[5];
        Integer maior = 0;
        Integer indice = 0;

        for (int i = 0; i < vetor.length; i++){
            System.out.println("Digite o nome do carro: \n");
            String carro = leitor.nextLine();
            vetor[i] = carro;
        }

        for (int i = 0; i < vetor2.length; i++){
            System.out.println("Digite o rendimento do carro: \n");
            Integer rendimento = leitor2.nextInt();
            vetor2[i] = rendimento;

            if (rendimento > maior){
                maior = rendimento;
                indice = i;
            }

        }




        System.out.println("O modelo mais economico é:  \n" + vetor[indice]);
    }
}
