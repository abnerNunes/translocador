public class ExercicioOrdena2 {
    //8
    public static void main(String[] args) {
        Integer v[]= {1, 7, 5, 2, 7, 1, 9, 2};

        int i = 0;
        int j = 0;
        int indMenor = 0;
        int aux = 0;
        int contaCompa = 0;
        int contaTroca = 0;

        for (i = 0; i < v.length - 1; i++){
            indMenor = i;
            for (j = i+1; j < v.length - 1; j++){
                contaCompa++;
                if (v[j] < v[indMenor]){
                    indMenor = j;
                }
            }
            contaTroca++;
            aux = v[i];
            v[i] = v[j];
            v[j] = aux;

        }

        for ( i = 0; i<v.length; i++){
            System.out.println(v[i]);
        }


    }
}
