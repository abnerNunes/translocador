import java.util.Scanner;

public class EsquemaDias {
    public static void main(String[] args) {
        Integer[] meses = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12};
        Scanner leitor = new Scanner(System.in);

        Integer mes = 0;

        do{
            System.out.println("Insira o mês: ");
            mes = leitor.nextInt();
        } while (mes > 12 || mes < 1);


        Integer dia = 0;

        do {
            System.out.println("Insira o dia: ");
             dia = leitor.nextInt();
        }while(dia<0 || dia>31);


        Integer diasSomadosMeses = meses[mes-2] * 31;

        Integer diaTotal = diasSomadosMeses + dia;

        System.out.println(diaTotal + " dia do ano");
    }
}
